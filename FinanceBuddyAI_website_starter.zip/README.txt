FinanceBuddyAI starter website

Files:
- index.html: responsive finance education website with budget and SIP illustration calculators.

Important:
- This is a static starter website, not yet connected to a live AI chatbot.
- To make it public, upload index.html to a static hosting provider (for example, GitHub Pages, Netlify, or Cloudflare Pages).
- To add a real AI chatbot, connect an AI API through a secure backend/server. Never put secret API keys in index.html.
- The calculators are educational estimates only and do not predict or guarantee returns.
